"""
app.py — NeuroVigilance v9 Streamlit entry point.

All heavy logic lives in the submodules; this file handles only UI flow.

Run with:
    streamlit run app.py
"""

import streamlit as st

from config import DRUG_CLASSES, BACKGROUND_DRUGS, BACKGROUND_DRUG_SYNONYMS
from data.faers_client  import fetch_drug_reports, build_report_and_rxn_dfs
from data.label_client  import fetch_label
from stats.prr          import compute_prr, weber_flag, rolling_prr
from literature.pubmed  import render_pubmed_section
from viz.forest         import forest_plot
from viz.volcano        import volcano_plot
from viz.temporal       import rolling_prr_chart
from viz.demographics   import demographic_charts
from viz.concordance    import concordance_scatter
from viz.validation     import render_validation_tab

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="NeuroVigilance v9",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&display=swap');
  html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
  .section-label {
    font-size: 10px; font-weight: 600; letter-spacing: 0.1em;
    text-transform: uppercase; color: #6B6760; margin: 16px 0 6px;
  }
  .method-card {
    background: #F6F4EF; border-radius: 8px; padding: 12px 16px;
    font-size: 12px; color: #3C3A35; margin-bottom: 12px;
  }
  .warn-card {
    background: #FAEEDA; border-radius: 8px; padding: 10px 14px;
    font-size: 12px; color: #633806; margin-bottom: 10px;
  }
  .pub-card {
    background: #F6F4EF; border-radius: 8px; padding: 12px 16px; margin-bottom: 8px;
  }
  .pub-title { font-size: 13px; font-weight: 500; margin-bottom: 3px; }
  .pub-title a { color: #3C3489; text-decoration: none; }
  .pub-meta { font-size: 11px; color: #6B6760; }
</style>
""", unsafe_allow_html=True)


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🧠 NeuroVigilance v9")
    st.markdown("FDA FAERS · PRR · EBGM · BCPNN/IC · FDR")
    st.divider()

    drug_class_name = st.selectbox("Drug Class", list(DRUG_CLASSES.keys()))
    cls = DRUG_CLASSES[drug_class_name]

    serious_filter = st.selectbox(
        "Seriousness Filter", ["All", "Serious", "Non-serious"]
    )

    min_n = st.slider(
        "Minimum reports (n)", 3, 30, 5,
        help="Reactions with n ≥ 3 formally satisfy the Evans n ≥ 3 criterion. "
             "The default of 5 hides n=3 and n=4 reactions from the table even "
             "when they meet Signal_Evans — lower to 3 to see all qualifying reactions."
    )

    st.divider()
    st.markdown(
        "<div style='font-size:10px;color:#6B6760;'>"
        "Data: FDA FAERS via openFDA API.<br>"
        "Primary suspect drugs only (characterization=1).<br>"
        "Deduplication by primaryid/caseversion.<br>"
        "BH-FDR corrected at α=0.05.<br>"
        "EBGM priors fit to corpus (≥30 cells).<br>"
        "EBGM via exact digamma formula (v9.1)."
        "</div>",
        unsafe_allow_html=True,
    )
    st.warning(
        "⚠️ **API mode: 1,000 reports/drug cap.** "
        "Signals from rare reactions may be underpowered. "
        "For production use, load full FAERS bulk files (see README_bulk.md).",
        icon=None,
    )
    st.warning(
        "⚠️ **Recency bias**: openFDA returns the most recent reports first. "
        "For drugs approved pre-2010 (Donepezil 1996, Fluoxetine 1987…), "
        "this corpus covers only ~2015–present, missing early post-market signals. "
        "**Signal_Evans is the recommended primary output** in API mode.",
        icon=None,
    )


# ── Main area ─────────────────────────────────────────────────────────────────
st.title(f"Signal Detection — {drug_class_name}")
st.caption(f"Indication: {cls['indication']}")

drugs       = cls["drugs"]
brands      = cls["brands"]
confounders = cls["confounders"]

# ── Data fetch ────────────────────────────────────────────────────────────────
# CRITICAL: If we only fetch the target class drugs, the background for DrugA
# is DrugB + DrugC — same class, same patients, same indication. Class-wide
# signals (e.g. bradycardia for all ChEIs) produce PRR ≈ 1.0, false null.
# Fix: fetch a diverse background panel from unrelated therapeutic classes
# and include them in report_df so the background is pharmacologically diverse.
with st.spinner("Fetching target class data…"):
    class_frames = [fetch_drug_reports(d) for d in drugs]

with st.spinner(f"Fetching {len(BACKGROUND_DRUGS)}-drug reference background…"):
    bg_frames = [
        fetch_drug_reports(d, synonyms=BACKGROUND_DRUG_SYNONYMS.get(d))
        for d in BACKGROUND_DRUGS
    ]

with st.spinner("Deduplicating and building analysis corpus…"):
    report_df, rxn_df = build_report_and_rxn_dfs(class_frames + bg_frames)

if report_df.empty:
    st.error("No FAERS data returned. Check your network connection or try again later.")
    st.stop()

n_total         = report_df["primaryid"].nunique()
n_class_reports = report_df[report_df["drug"].isin(drugs)]["primaryid"].nunique()
n_bg_reports    = report_df[~report_df["drug"].isin(drugs)]["primaryid"].nunique()
st.success(
    f"Loaded **{n_total:,}** unique cases: "
    f"**{n_class_reports:,}** cases involving target drugs + "
    f"**{n_bg_reports:,}** cases involving background drugs "
    f"(some cases may appear in both due to polypharmacy)."
)
st.info(
    "ℹ️ **Background methodology**: PRR is computed against a diverse multi-class "
    "background panel rather than only within-class drugs. Without this, class-wide "
    "pharmacodynamic effects (e.g. bradycardia for all ChEIs) produce PRR ≈ 1.0 — "
    "a false null that suppresses the signals most relevant to the drug class. "
    "**Known limitation:** Background drugs are cardiovascular/metabolic (Metformin, "
    "Lisinopril, Atorvastatin…). Neuropsychiatric drug patients are systematically "
    "older and sicker — reactions common in elderly or severely ill patients (falls, "
    "UTI, aspiration, dehydration) may show **spuriously elevated PRR** due to patient "
    "population differences, not drug effects. Verify demographic plausibility before "
    "acting on such signals.",
    icon=None,
)

# ── Tabs: per-drug + Validation ───────────────────────────────────────────────
tabs = st.tabs(drugs + ["🔬 Validation"])

# Validation tab is the last tab
*drug_tabs, validation_tab = tabs

with validation_tab:
    st.markdown("### Known-Signal Validation")
    st.caption(
        "Confirms the signal detection pipeline reproduces established pharmacovigilance findings. "
        "Load any drug class to run — validation pairs span all three classes."
    )
    render_validation_tab(report_df, rxn_df, drug_classes=DRUG_CLASSES)

for tab, drug in zip(drug_tabs, drugs):
    with tab:

        # Label fetch
        with st.spinner(f"Fetching FDA label for {drug}…"):
            label_text = fetch_label(drug, brands)

        # Warn if label fetch failed — novel signal detection is blind in this state
        if not label_text:
            st.warning(
                f"⚠️ **FDA label unavailable for {drug}** — the openFDA label API "
                f"returned no content. All reactions will be marked `Labeled: True` "
                f"(conservative fallback). Novel signal detection is **disabled** for "
                f"this drug until the label is retrievable.",
                icon=None,
            )

        # Clozapine safety context: REMS requirement
        if drug == "Clozapine":
            st.warning(
                "⚠️ **Clozapine Black Box Warning**: Clozapine requires mandatory REMS "
                "enrollment for agranulocytosis monitoring. Hematologic signals "
                "(agranulocytosis, neutropenia) are likely underpowered at API corpus sizes. "
                "Absence of a signal does NOT indicate safety for hematologic reactions.",
                icon=None,
            )

        # Compute
        with st.spinner(f"Computing PRR / EBGM / IC for {drug}…"):
            res, ebgm_fit_ok = compute_prr(
                rxn_df=rxn_df,
                report_df=report_df,
                drug=drug,
                confounders=confounders,
                serious_filter=serious_filter,
                label_text=label_text,
                fit_ebgm=True,
                min_n=min_n,   # display filter; BH-FDR applied over full a>=3 set inside compute_prr
            )

        # Surface EBGM fallback warning to user
        if not ebgm_fit_ok:
            st.warning(
                "⚠️ **EBGM prior fitting did not converge** — fewer than 30 "
                "drug-reaction cells or optimisation failed. "
                "DuMouchel (1999) population-level priors used instead. "
                "EBGM values may be less well-calibrated to this corpus."
            )

        if res is None or res.empty:
            st.warning(f"No signals computed for {drug}. Insufficient data.")
            continue

        # Per-drug Signal_Group override: constipation is anticholinergic for
        # antipsychotics (can progress to paralytic ileus, esp. clozapine) but
        # disease-related for ChEIs. Override the global map here.
        _AP_DRUGS = set(DRUG_CLASSES.get("Atypical Antipsychotics", {}).get("drugs", []))
        if drug in _AP_DRUGS and not res.empty and "Signal_Group" in res.columns:
            res = res.copy()
            res.loc[res["Reaction"] == "Constipation", "Signal_Group"] = "GI/Anticholinergic"

        # Surface c=0 dropped reactions (PRR undefined, no background cases)
        c0_n = res.attrs.get("c0_dropped", 0)
        if c0_n > 0:
            c0_examples = ", ".join(res.attrs.get("c0_reactions", [])[:3])
            st.info(
                f"ℹ️ **{c0_n} reaction(s) had zero background cases** and could not "
                f"have PRR computed (formula undefined at c=0). These may represent "
                f"drug-specific novel reactions. Examples: {c0_examples}. "
                f"Consider searching these manually in the FDA Adverse Events system.",
                icon=None,
            )

        # ── Summary metrics ──────────────────────────────────────────────────
        n_signals_evans = int(res["Signal_Evans"].sum())
        n_signals       = int(res["Signal"].sum())
        n_novel         = int(((~res["Labeled"]) & res["Signal_Evans"]).sum())
        n_strong        = int((res["Tier"] == "STRONG").sum())
        top_prr         = float(res["PRR"].max())

        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric("Signals (Evans)",  n_signals_evans)
        c2.metric("Signals (GPS+FDR)", n_signals)
        c3.metric("Novel (unlabeled)", n_novel)
        c4.metric("STRONG tier",       n_strong)
        c5.metric("Max PRR",           f"{top_prr:.1f}×")

        # ── Signal table ─────────────────────────────────────────────────────
        st.markdown("#### Disproportionality Table")
        st.caption(
            "**Signal_Evans** = PRR ≥ 2, χ² ≥ 4, n ≥ 3 (Evans 2001 / EMA criterion; "
            "Fisher's exact test substituted when min expected cell < 5, as the Pearson "
            "χ² approximation is invalid below that threshold). "
            "**Note:** WHO-UMC uses a distinct Bayesian criterion (IC025 > 0), shown in the Concordance column. "
            "**Signal** = Signal_Evans AND BH-FDR p < 0.05 AND EB05 ≥ 2.0 (GPS Bayesian lower bound). "
            "At API corpus sizes (≤1,000 reports/drug), GPS posteriors are prior-dominated — "
            "**Signal_Evans is the recommended primary output** in this regime. "
            "⚠️ **Composite score** is a heuristic ranking tool (unpublished weights); "
            "PRR/EBGM are correlated (r > 0.9); do not interpret as a p-value."
        )
        show_cols = [
            "Reaction", "n", "PRR", "CI_lo", "CI_hi", "ROR", "ROR_lo", "ROR_hi",
            "EBGM", "EB05", "IC", "IC025", "IC975",
            "Chi2", "p_adj",
            "Tier", "Signal_Evans", "Signal", "Labeled", "Confound", "Signal_Group",
            "Concordance", "Composite",
        ]
        disp = res[[c for c in show_cols if c in res.columns]].copy()
        st.dataframe(
            disp.style.format({
                "PRR": "{:.2f}", "CI_lo": "{:.2f}", "CI_hi": "{:.2f}",
                "ROR": "{:.2f}", "ROR_lo": "{:.2f}", "ROR_hi": "{:.2f}",
                "EBGM": "{:.2f}", "EB05": "{:.2f}",
                "IC": "{:.2f}", "IC025": "{:.2f}", "IC975": "{:.2f}",
                "Chi2": "{:.1f}", "p_adj": "{:.4f}",
                "Composite": "{:.3f}",
            }),
            use_container_width=True,
            height=400,
        )

        st.divider()

        # ══════════════════════════════════════════════════════════════════
        # VISUALISATIONS
        # ══════════════════════════════════════════════════════════════════

        with st.expander("📊 Forest Plot — PRR + 95% CI", expanded=True):
            st.markdown(
                "<div class='method-card'>Haldane-corrected CI with log-normal "
                "95% intervals. Point estimate uses standard Evans formula (a/td)÷(c/to). "
                "PRR=2 dashed red line = FDA signal threshold. "
                "🆕 = novel unlabeled reaction. "
                "<b>Note:</b> EB05 (GPS 5th-percentile) uses 2,000-point numerical quadrature — "
                "accurate to &lt;0.5% vs. exact solution. "
                "Use Signal_Evans (Evans criterion) as primary filter at small n.</div>",
                unsafe_allow_html=True,
            )
            sig_only = st.toggle(
                "Signals only", value=False, key=f"sig_only_{drug}"
            )
            fig_f = forest_plot(res, drug, max_reactions=30, show_only_signals=sig_only)
            st.plotly_chart(fig_f, use_container_width=True)

        with st.expander("🌋 Volcano Plot — Effect Size vs Statistical Evidence"):
            st.markdown(
                "<div class='method-card'>X: log₂(PRR) effect size. "
                "Y: −log₁₀(BH-adjusted p). "
                "Upper-right = strong, significant signals. "
                "Point size ∝ √n. Top 10 signals labelled.</div>",
                unsafe_allow_html=True,
            )
            fig_v = volcano_plot(res, drug)
            st.plotly_chart(fig_v, use_container_width=True)

        with st.expander("🔬 Three-Framework Concordance — PRR × EBGM × IC"):
            st.markdown(
                "<div class='method-card'>Signal robustness across PRR, EBGM/GPS, "
                "and BCPNN/IC frameworks. Color = IC value. "
                "Bold outline = passed all signal criteria. "
                "Diagonal = perfect PRR/EBGM agreement.</div>",
                unsafe_allow_html=True,
            )
            fig_c = concordance_scatter(res, drug)
            st.plotly_chart(fig_c, use_container_width=True)

        # Pre-filter rxn_df and report_df for seriousness once, shared by all downstream
        # analyses (rolling PRR, Weber, demographics). Without this, the temporal chart
        # and Weber check reflect the full population even when a seriousness filter is
        # active, making them inconsistent with the main signal table.
        if serious_filter != "All":
            _valid_ids = set(report_df[report_df["serious"] == serious_filter]["primaryid"])
            _filtered_report = report_df[report_df["primaryid"].isin(_valid_ids)]
            _filtered_rxn    = rxn_df[rxn_df["primaryid"].isin(_valid_ids)]
        else:
            _filtered_report = report_df
            _filtered_rxn    = rxn_df

        with st.expander("📈 Temporal Stability — Rolling PRR by Quarter"):
            st.markdown(
                "<div class='method-card'>4-quarter rolling PRR for top signals. "
                "Sustained elevation = stable pharmacological signal. "
                "Early spike then decay = possible Weber effect. "
                "Weber window anchored to FDA approval date.</div>",
                unsafe_allow_html=True,
            )
            with st.spinner("Computing rolling PRR…"):
                top_rxns_for_roll = (
                    res[res["Signal_Evans"]]["Reaction"].head(6).tolist()
                    if res["Signal_Evans"].any()
                    else res["Reaction"].head(6).tolist()
                )
                roll_df = rolling_prr(_filtered_rxn, _filtered_report, drug, top_rxns_for_roll)

            fig_r = rolling_prr_chart(roll_df, drug, top_n=6, window=4)
            if fig_r is not None:
                st.plotly_chart(fig_r, use_container_width=True)
            else:
                st.info("Insufficient quarterly data for temporal analysis.")

        # Demographics uses the same seriousness-filtered population as rolling PRR / Weber
        demo_report_df = _filtered_report
        demo_rxn_df    = _filtered_rxn

        top_rxn_for_demo = res.iloc[0]["Reaction"] if not res.empty else None
        if top_rxn_for_demo:
            with st.expander(f"👥 Demographics — {drug} × {top_rxn_for_demo}"):
                st.markdown(
                    "<div class='method-card'>Age distribution and sex breakdown: "
                    "drug reports WITH the top reaction (cases) vs. WITHOUT (controls). "
                    "Identifies demographic subgroup enrichment. "
                    "Population matches active seriousness filter.</div>",
                    unsafe_allow_html=True,
                )
                fig_d = demographic_charts(demo_report_df, demo_rxn_df, drug, top_rxn_for_demo)
                if fig_d is not None:
                    st.plotly_chart(fig_d, use_container_width=True)
                else:
                    st.info(f"Insufficient demographic data for {top_rxn_for_demo}.")

        # ══════════════════════════════════════════════════════════════════
        # LITERATURE + WEBER
        # ══════════════════════════════════════════════════════════════════

        top_signals = res[res["Signal_Evans"]].head(3)

        st.divider()
        st.markdown("#### Literature Context")
        if not top_signals.empty:
            with st.expander(f"📚 Literature Context — {drug}"):
                st.markdown(
                    "<div class='method-card'>PubMed literature for top Evans signals.</div>",
                    unsafe_allow_html=True,
                )
                for _, sig_row in top_signals.iterrows():
                    render_pubmed_section(drug, sig_row["Reaction"])
        else:
            st.info("No signals detected — literature query skipped.")

        st.divider()
        st.markdown("#### Weber Effect Check")
        if not top_signals.empty:
            for _, sig_row in top_signals.iterrows():
                rxn_w = sig_row["Reaction"]
                flagged, pct = weber_flag(_filtered_rxn, drug, rxn_w)
                if pct is not None:
                    badge = "⚠️ Weber flag" if flagged else "✅ Not Weber-flagged"
                    st.markdown(
                        f"**{rxn_w}**: {badge} — "
                        f"{pct:.0f}% of reports in first 3 years post-approval "
                        f"(threshold: 60%)"
                    )
                else:
                    st.markdown(f"**{rxn_w}**: Insufficient data for Weber analysis.")
        else:
            st.info("No signals detected.")

        # ── Download ──────────────────────────────────────────────────────────
        st.divider()
        st.download_button(
            label=f"⬇ Download {drug} results (CSV)",
            data=res.to_csv(index=False).encode("utf-8"),
            file_name=f"neurovigilance_{drug.lower()}_signals.csv",
            mime="text/csv",
        )
